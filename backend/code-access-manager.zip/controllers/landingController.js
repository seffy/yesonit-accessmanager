exports.showLandingPage = (req, res) => {
  res.render('landing');
};